
USE [master]
GO

CREATE DATABASE Quiz;

USE [Quiz]
GO

/****** Object: Table [dbo].[Answers] Script Date: 2020-09-11 9:35:08 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Answers] (
    [AnswerID]   INT IDENTITY (1, 1) NOT NULL,
    [ChoiceID]   INT NULL,
    [QuestionID] INT NULL,
    [Score]      INT NULL,
    [QuizID]     INT NULL
);


GO

USE [Quiz]
GO

/****** Object: Table [dbo].[Choices] Script Date: 2020-09-11 9:37:11 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Choices] (
    [ChoiceID]   INT           IDENTITY (1, 1) NOT NULL,
    [ChoiceText] VARCHAR (MAX) NULL,
    [QuestionID] INT           NULL
);


Go
USE [Quiz]
GO

/****** Object: Table [dbo].[Questions] Script Date: 2020-09-11 9:37:24 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Questions] (
    [QuestionID]        INT           IDENTITY (1, 1) NOT NULL,
    [QuestionText]      VARCHAR (MAX) NULL,
    [QuizID]            INT           NULL,
    [IsSingleSelection] BIT           NULL
);

USE [Quiz]
GO

/****** Object: Table [dbo].[Quiz] Script Date: 2020-09-11 9:37:38 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Quiz] (
    [QuizID]   INT          IDENTITY (1, 1) NOT NULL,
    [QuizName] VARCHAR (80) NULL
);


GO

USE [Quiz]
GO

/****** Object: Table [dbo].[UserChoices] Script Date: 2020-09-11 9:37:54 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UserChoices] (
    [Id]         INT IDENTITY (1, 1) NOT NULL,
    [UserID]     INT NULL,
    [QuestionID] INT NULL,
    [ChoiceID]   INT NULL,
    [QuizID]     INT NULL
);

GO

USE [Quiz]
GO

/****** Object: Table [dbo].[UserQuestionSeq] Script Date: 2020-09-11 9:38:06 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UserQuestionSeq] (
    [id]         INT IDENTITY (1, 1) NOT NULL,
    [UserID]     INT NULL,
    [QuestionID] INT NULL,
    [QuizID]     INT NULL
);


GO

USE [Quiz]
GO

/****** Object: Table [dbo].[Users] Script Date: 2020-09-11 9:38:16 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Users] (
    [UserID]   INT          IDENTITY (1, 1) NOT NULL,
    [FullName] VARCHAR (50) NULL
);






