SET IDENTITY_INSERT [dbo].[Questions] ON
INSERT INTO [dbo].[Questions] ([QuestionID], [QuestionText], [QuizID], [IsSingleSelection]) VALUES (1, N'What is the Capital of Canada?', 1, 1)
INSERT INTO [dbo].[Questions] ([QuestionID], [QuestionText], [QuizID], [IsSingleSelection]) VALUES (2, N'What are the Offical languages of Canada?', 1, 0)
INSERT INTO [dbo].[Questions] ([QuestionID], [QuestionText], [QuizID], [IsSingleSelection]) VALUES (3, N'Which Leaf in the Flag of Canada ?', 1, 1)
INSERT INTO [dbo].[Questions] ([QuestionID], [QuestionText], [QuizID], [IsSingleSelection]) VALUES (4, N'Who is the King of Jungle ?', 2, 1)
INSERT INTO [dbo].[Questions] ([QuestionID], [QuestionText], [QuizID], [IsSingleSelection]) VALUES (5, N'Who is the best runner?', 2, 1)
INSERT INTO [dbo].[Questions] ([QuestionID], [QuestionText], [QuizID], [IsSingleSelection]) VALUES (6, N'Who is the mamal which can fly ?', 2, 1)
INSERT INTO [dbo].[Questions] ([QuestionID], [QuestionText], [QuizID], [IsSingleSelection]) VALUES (7, N'Who are the best predators? ', 2, 0)
SET IDENTITY_INSERT [dbo].[Questions] OFF
