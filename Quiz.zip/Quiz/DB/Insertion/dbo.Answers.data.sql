SET IDENTITY_INSERT [dbo].[Answers] ON
INSERT INTO [dbo].[Answers] ([AnswerID], [ChoiceID], [QuestionID], [Score], [QuizID]) VALUES (1, 4, 1, 40, 1)
INSERT INTO [dbo].[Answers] ([AnswerID], [ChoiceID], [QuestionID], [Score], [QuizID]) VALUES (2, 6, 2, 5, 1)
INSERT INTO [dbo].[Answers] ([AnswerID], [ChoiceID], [QuestionID], [Score], [QuizID]) VALUES (3, 7, 2, 5, 1)
INSERT INTO [dbo].[Answers] ([AnswerID], [ChoiceID], [QuestionID], [Score], [QuizID]) VALUES (4, 10, 3, 50, 1)
INSERT INTO [dbo].[Answers] ([AnswerID], [ChoiceID], [QuestionID], [Score], [QuizID]) VALUES (5, 16, 4, 25, 2)
INSERT INTO [dbo].[Answers] ([AnswerID], [ChoiceID], [QuestionID], [Score], [QuizID]) VALUES (6, 17, 5, 25, 2)
INSERT INTO [dbo].[Answers] ([AnswerID], [ChoiceID], [QuestionID], [Score], [QuizID]) VALUES (7, 20, 6, 25, 2)
INSERT INTO [dbo].[Answers] ([AnswerID], [ChoiceID], [QuestionID], [Score], [QuizID]) VALUES (8, 24, 7, 13, 2)
INSERT INTO [dbo].[Answers] ([AnswerID], [ChoiceID], [QuestionID], [Score], [QuizID]) VALUES (9, 25, 7, 12, 2)
SET IDENTITY_INSERT [dbo].[Answers] OFF
