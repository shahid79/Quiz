SET IDENTITY_INSERT [dbo].[Quiz] ON
INSERT INTO [dbo].[Quiz] ([QuizID], [QuizName]) VALUES (1, N'Canada ')
INSERT INTO [dbo].[Quiz] ([QuizID], [QuizName]) VALUES (2, N'Jungle')
SET IDENTITY_INSERT [dbo].[Quiz] OFF
