﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace QuizThroughRzPages.Models
{
    public class Questions
    {
     
        [Key]
        public int QuestionID { get; set; }
        public string QuestionText { get; set; }
        public int QuizID { get; set; }
        //public Choices choices { get; set; }
        public bool IsSingleSelection { get; set; }
    }
}
