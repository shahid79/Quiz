﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuizThroughRzPages.Models
{
    public class UserQuestionSeq
    {


        public int id { get; set; }
        public int UserID { get; set; }        
        public int QuestionID { get; set; }
        public int QuizID { get; set; }

    }
}
