﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace QuizThroughRzPages.Models
{
    public class Choices
    {
     
        
        [Key]
        public int ChoiceID { get; set; }
        public string ChoiceText { get; set; }
        public int QuestionID { get; set; }


    }
}
