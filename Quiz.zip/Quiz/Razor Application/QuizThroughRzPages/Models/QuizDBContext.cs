﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace QuizThroughRzPages.Models
{
    public class QuizDBContext : DbContext
    {
        public QuizDBContext(DbContextOptions options)
            : base(options)
        {
        }

        public DbSet<Quiz> Quiz { get; set; }
        public DbSet<Questions> questions { get; set; }
        public DbSet<Choices> choices { get; set; }
        public DbSet<UserChoices> userChoices { get; set; }
        public DbSet<Users> users { get; set; }
        public DbSet<Answers> answers { get; set; }
        public DbSet<UserQuestionSeq> UserQuestionSeq { get; set; }

}
    
}
