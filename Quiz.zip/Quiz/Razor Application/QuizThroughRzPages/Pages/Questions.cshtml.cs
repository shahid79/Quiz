﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using QuizThroughRzPages.Models;

namespace QuizThroughRzPages.Pages
{
    public class OptionViewModel
    {
        public int ChoiceID { get; set; }
        public string ChoiceText { get; set; }
    }

    public class QuestionViewModel
    {
        public int QuestionId { get; set; }
        public int ExamQuestionOrder { get; set; }
        public string QuestionText { get; set; }
        public bool? IsSingleSelection { get; set; }
        public List<OptionViewModel> Options { get; set; }
    }

    public class QuestionsModel : PageModel
    {
        private readonly QuizDBContext _context;
        public QuestionsModel(QuizDBContext context)
        {
            _context = context;
        }



        [BindProperty]
        public Questions questions { get; set; }

        [BindProperty]
        public QuestionViewModel QuestionViewModel { get; set; }

        [BindProperty]
        public int AnswerSelectedId { get; set; }   //this is the key bit

        [BindProperty]
        public List<int> AreChecked { get; set; }   //this is the key bit

        public UserQuestionSeq userQuestionSeqs { get; set; }

        public ActionResult OnPostLogOut()
        {
            //do your work here\
            HttpContext.Session.Clear();
            return RedirectToPage("Login");
        }
        public IActionResult OnGet(int id)
        {

            //The user should be able to resume a quiz if the browser is closed.


            HttpContext.Session.SetInt32("QuizID", id);
            if (BrokenJourney())
            {
                NextQuestion();
                return Page();
            }

            //The order of questions shall be randomly sorted when requested from the server.


            List<UserQuestionSeq> uc =  _context.UserQuestionSeq
                .Where(o => o.UserID == HttpContext.Session.GetInt32("UserID")
                && o.QuizID == HttpContext.Session.GetInt32("QuizID")).ToList();

            if (uc.Count > 0)
            {
                _context.UserQuestionSeq.RemoveRange(uc);
                _context.SaveChanges();
            }


            int _Min = _context.questions.Where(o => o.QuizID == id).Min(p => p.QuestionID);
            int _Max = _context.questions.Where(o => o.QuizID == id).Max(p=>p.QuestionID); 


            foreach (int i in UniqueRandom(_Min, _Max))
            {
                //Console.WriteLine(i);
                userQuestionSeqs = new UserQuestionSeq()
                {
                    QuestionID = i,
                    QuizID = id,
                    UserID = (int)HttpContext.Session.GetInt32("UserID")
                };
                _context.Add(userQuestionSeqs);
                _context.SaveChanges();
              }



            
            //
            var userseq = _context.UserQuestionSeq.Where(o => o.QuizID == id).FirstOrDefault();
            int tid = userseq.QuestionID;
            questions = _context.questions.Where(o => o.QuestionID == tid).FirstOrDefault();

            
            string qtxt = questions.QuestionText;
            

            //OptionViewModel x = new List<OptionViewModel>();
            var x = _context.choices.Where(o => o.QuestionID == tid).OrderBy( r=>Guid.NewGuid() )
                             .Select(x => new OptionViewModel
                             {
                                 ChoiceID = x.ChoiceID,
                                 ChoiceText = x.ChoiceText
                             }).ToList();

            HttpContext.Session.SetInt32("QuestionID", tid);
            HttpContext.Session.SetInt32("SequenceID", userseq.id);

            QuestionViewModel = new QuestionViewModel
            {
                QuestionId = tid,
                ExamQuestionOrder = 1,
                QuestionText = qtxt,
                IsSingleSelection = questions.IsSingleSelection,
                Options = new List<OptionViewModel>()
            
            };

            QuestionViewModel.Options = x;


            return Page();
        }

        IEnumerable<int> UniqueRandom(int minInclusive, int maxInclusive)
        {
            List<int> candidates = new List<int>();
            for (int i = minInclusive; i <= maxInclusive; i++)
            {
                candidates.Add(i);
            }
            Random rnd = new Random();
            while (candidates.Count > 0)
            {
                int index = rnd.Next(candidates.Count);
                yield return candidates[index];
                candidates.RemoveAt(index);
            }
        }

        
        public IActionResult OnPostAsync()
        {


            SaveUserChoices();
           if  (!NextQuestion())
            {
                int id = (int)HttpContext.Session.GetInt32("UserID");
                return RedirectToPage("Index",
                    new { id });

            }




            return Page();
            //return Content($"The answer selected was {AnswerSelectedId} ");

        }

        public bool SaveUserChoices()
        {


            try
            {


                if (AreChecked.Count == 0 || AnswerSelectedId != 0 )
                {
                    UserChoices uc = new UserChoices();
                    uc.UserID = (int)HttpContext.Session.GetInt32("UserID");

                    uc.ChoiceID = AnswerSelectedId;

                    uc.QuestionID = (int)HttpContext.Session.GetInt32("QuestionID");

                    uc.QuizID = (int)HttpContext.Session.GetInt32("QuizID");

                    _context.Add(uc);
                    _context.SaveChanges();
                }
                else
                {
                    for (int iCount= 0; iCount <  AreChecked.Count; iCount++ )
                    {

                        UserChoices uc = new UserChoices();
                        uc.UserID = (int)HttpContext.Session.GetInt32("UserID"); ;

                        uc.ChoiceID = AreChecked[iCount];

                        uc.QuestionID = (int)HttpContext.Session.GetInt32("QuestionID");
                        uc.QuizID = (int)HttpContext.Session.GetInt32("QuizID");
                        _context.Add(uc);
                        _context.SaveChanges();

                    }

                }
                    return true;
            }
            catch(Exception ex)
            {

            }

            return false;

        }


        public bool NextQuestion()
        {


            var userseq = _context.UserQuestionSeq
                .Where(o => o.QuizID == HttpContext.Session.GetInt32("QuizID")
                && o.id > HttpContext.Session.GetInt32("SequenceID")
                ).FirstOrDefault();

            if ( userseq !=null)
            { 
            questions = 
                _context.questions.Where(o => o.QuestionID == userseq.QuestionID
            && o.QuizID == HttpContext.Session.GetInt32("QuizID")
            ).FirstOrDefault();
            
            if (questions != null)
            {
                var tid = questions.QuestionID;
                var x = _context.choices.Where(o => o.QuestionID == tid  ).OrderBy(r => Guid.NewGuid())
                                 .Select(x => new OptionViewModel
                                 {
                                     ChoiceID = x.ChoiceID,
                                     ChoiceText = x.ChoiceText
                                 }).ToList();

                HttpContext.Session.SetInt32("QuestionID", tid);
                HttpContext.Session.SetInt32("SequenceID", userseq.id);

                QuestionViewModel = new QuestionViewModel
                {
                    QuestionId = tid,
                    ExamQuestionOrder = 1,
                    QuestionText = questions.QuestionText,
                    IsSingleSelection = questions.IsSingleSelection,
                    Options = new List<OptionViewModel>()

                };

                QuestionViewModel.Options = x;
                return true;
            }
            }
            return false;

        }

        public bool BrokenJourney()
        {


            int userJourneyID = _context.userChoices
                        .Where(
                o => o.UserID == HttpContext.Session.GetInt32("UserID")
                && o.QuizID == HttpContext.Session.GetInt32("QuizID")
                        )
                        .Max(e => (int?)e.id) ?? 0;


            


            if (userJourneyID > 0)
            {

                int userJourneyQuestionID = _context.userChoices
                        .Where(
                o => o.id == userJourneyID
                        )
                        .Max(e => (int?)e.QuestionID) ?? 0;

                var userseqLastId = _context.UserQuestionSeq
                .Where(o => o.QuizID == HttpContext.Session.GetInt32("QuizID")
                && o.QuestionID == userJourneyQuestionID
                && o.UserID == HttpContext.Session.GetInt32("UserID")).FirstOrDefault();


                if (userseqLastId != null)
                {
                    HttpContext.Session.SetInt32("SequenceID", userseqLastId.id);
                    return true;
                }
                
            }

            return false;

            
        }

    }


}