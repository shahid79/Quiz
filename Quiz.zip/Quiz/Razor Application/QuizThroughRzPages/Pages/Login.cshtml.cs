﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using QuizThroughRzPages.Models;
using Microsoft.AspNetCore.Http;


namespace QuizThroughRzPages.Pages
{
    public class LoginModel : PageModel
 
    {


        private readonly QuizDBContext _context;
                       public LoginModel(QuizDBContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Users users { get; set; }

        public ActionResult OnGet()
        {
            return Page();

        }

        public async Task<IActionResult> OnPostAsync()
        {

            int id;

            var isExist = _context.users.Where(f => f.FullName == users.FullName).FirstOrDefault();

            HttpContext.Session.SetString("FullName", users.FullName);         


            if (isExist == null)
            {
                _context.users.Add(users);
                await _context.SaveChangesAsync();
                id = users.UserID;
            }
            else
            { id = isExist.UserID; }

            

            
            return RedirectToPage("Index", new { id });
        }


    }
}