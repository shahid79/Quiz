﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using QuizThroughRzPages.Models;

namespace QuizThroughRzPages.Pages
{
    public class ScoreViewModel
    {
        public int QuizID { get; set; }
        public int Score { get; set; }

        public string status {get; set;}
        public string QuizName { get; set; }
    }

    public class IndexModel : PageModel
    {
        
        private readonly QuizDBContext _context;

        public string Message { get; private set; } = "PageModel in C#";

        [BindProperty]
        public List<ScoreViewModel> ScoreViewModel { get; set; }


        public IndexModel(QuizDBContext context)
        {
            _context = context;
        }

        [BindProperty]
        public List<Quiz> Quiz { get; set; }
        [BindProperty]
        public string FullName { get; set; }
        public IActionResult OnGet(int id)
        {

            if (HttpContext.Session.GetInt32("UserID") > 0)
            {
                id = (int)HttpContext.Session.GetInt32("UserID");

            }

            if (id > 0) {

                FullName = HttpContext.Session.GetString("FullName");
                HttpContext.Session.SetInt32("UserID",id);

                ScoreViewModel = new List<ScoreViewModel>();

                Quiz = _context.Quiz.ToList();

                for (int iCount = 0; iCount < Quiz.Count(); iCount++)
                {
                    ScoreViewModel.Add(new ScoreViewModel
                    {
                        QuizID = Quiz[iCount].QuizID,
                        QuizName = Quiz[iCount].QuizName,
                        Score = CalculateTotal(Quiz[iCount].QuizID),
                        status = CalculateStatus(Quiz[iCount].QuizID)
                    });
                }
            }
           


            return Page();
        }

        public ActionResult OnPostLogOut()
        {
            //do your work here\
            HttpContext.Session.Clear();
            return RedirectToPage("Login");
        }


        public ActionResult OnPost(int id)
        {
            
            return RedirectToPage("Questions",new { id });


        }

        public  int CalculateTotal(int QuizID)
        {

           
            int Score = 0; 

            List<Answers> Ans = _context.answers.Where(a => a.QuizID == QuizID).Select( a => a).ToList();
            
            List<UserChoices> uc = _context.userChoices.Where(a => a.QuizID == QuizID 
                            && a.UserID == HttpContext.Session.GetInt32("UserID"))
                .Select(a => a).ToList();

            if (Ans.Count == 0 || uc.Count ==0 )
            {
                return 0;
            }


            for (int iCount = 0; iCount < Ans.Count(); iCount++)
            {
                var isExist =  uc.Where(p => p.QuestionID == Ans[iCount].QuestionID && 
                p.ChoiceID == Ans[iCount].ChoiceID).FirstOrDefault();
                if (isExist!= null)
                { Score += Ans[iCount].Score; }
            }

            return Score;

        }

        public string CalculateStatus(int QuizID)
        {
            int uc = _context.userChoices.Where(d => d.UserID == HttpContext.Session.GetInt32("UserID")
            && d.QuizID == QuizID ).Select(d => d.QuestionID)
                .Distinct().Count(); 

            int ans =  _context.answers
                .Where(a => a.QuizID == QuizID)
                .Select(d => d.QuestionID)
                .Distinct().Count();

            if (uc >= ans )
            {

                return "Completed";

            }
            else if (uc < ans)
            {
                return "Not Complete";
            }
            else
            {
                return "Not Started";
            }
            



        }


    }
}
